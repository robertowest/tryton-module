from trytond.model import ModelView, ModelSQL, fields, Unique
from trytond.pyson import Eval

__all__ = ['Sacerdote']


class Sacerdote(ModelSQL, ModelView):
    "Sacerdote"
    __name__ = 'curia.sacerdote'
    _rec_name = 'apellido'

    apellido    = fields.Char('Apellido', required=True)
    nombre      = fields.Char('Nombre', required=True)
    dni         = fields.Char('DNI')
    fnacimiento = fields.Date('Fec. Nacimiento')
    fordenacion = fields.Date('Fec. Ordenacion')
    protocolo   = fields.Char('Protocolo ')
    active      = fields.Boolean('Activo')

    @classmethod
    def __setup__(cls):
        super(Sacerdote, cls).__setup__()
        cls._order.insert(0, ('apellido', 'ASC'))
        cls._order.insert(0, ('nombre', 'ASC'))

        cls._error_messages.update({'err_mostrar_valor': ('variable "%(variable)s" valor "%(valor)s"'),
                                   })

    @classmethod
    def write(cls, *args):
        actions = iter(args)
        args = []

        for sacerdotes, values in zip(actions, actions):
            for key, value in values.iteritems():
                if key == 'apellido':
                    values['apellido'] = values['apellido'].upper()

                if key == 'nombre':
                    values['nombre'] = values['nombre'].title()

            args.extend((sacerdotes, values))

        super(Sacerdote, cls).write(*args)

    @staticmethod
    def default_active():
        return True
