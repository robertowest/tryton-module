from trytond.pool import Pool
