from trytond.model import ModelView, ModelSQL, fields, Unique

# Nombre interno de la clase, se utiliza como referencia dentro de Tryton
# en Tryton: <modulo> + . + <clase>
# en db    : <modulo> + _ + <clase>

__all__ = ['Sacerdote']


class Sacerdote(ModelSQL, ModelView):
    "Sacerdote"
    __name__ = 'curia.sacerdote'
    _rec_name = 'apellido'

    apellido    = fields.Char('Apellido', required=True)
    nombre      = fields.Char('Nombre', required=True)
    dni         = fields.Char('DNI')
    fnacimiento = fields.Date('Fec. Nacimiento')
    fordenacion = fields.Date('Fec. Ordenacion')
    protocolo   = fields.Char('Protocolo ')
    active      = fields.Boolean('Activo')
